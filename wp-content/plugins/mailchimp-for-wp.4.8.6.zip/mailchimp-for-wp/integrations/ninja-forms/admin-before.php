<p>
	<?php echo sprintf( __( 'To integrate with Ninja Forms, add the "Mailchimp" action to <a href="%s">one of your Ninja Forms forms</a>.', 'mailchimp-for-wp' ), admin_url( 'admin.php?page=ninja-forms' ) ); ?>
</p>
