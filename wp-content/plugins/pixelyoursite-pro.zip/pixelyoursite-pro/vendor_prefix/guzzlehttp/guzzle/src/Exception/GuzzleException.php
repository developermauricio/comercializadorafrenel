<?php

namespace PYS_PRO_GLOBAL\GuzzleHttp\Exception;

use PYS_PRO_GLOBAL\Psr\Http\Client\ClientExceptionInterface;
interface GuzzleException extends \PYS_PRO_GLOBAL\Psr\Http\Client\ClientExceptionInterface
{
}
