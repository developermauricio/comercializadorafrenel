<?php

namespace PYS_PRO_GLOBAL\GuzzleHttp\Exception;

final class InvalidArgumentException extends \InvalidArgumentException implements \PYS_PRO_GLOBAL\GuzzleHttp\Exception\GuzzleException
{
}
