<?php

namespace PYS_PRO_GLOBAL\GuzzleHttp\Exception;

/**
 * Exception when a server error is encountered (5xx codes)
 */
class ServerException extends \PYS_PRO_GLOBAL\GuzzleHttp\Exception\BadResponseException
{
}
