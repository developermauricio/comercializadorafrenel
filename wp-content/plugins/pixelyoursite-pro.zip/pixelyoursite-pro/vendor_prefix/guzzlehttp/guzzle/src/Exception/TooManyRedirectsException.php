<?php

namespace PYS_PRO_GLOBAL\GuzzleHttp\Exception;

class TooManyRedirectsException extends \PYS_PRO_GLOBAL\GuzzleHttp\Exception\RequestException
{
}
