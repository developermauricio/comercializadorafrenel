<?php

namespace PYS_PRO_GLOBAL\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements \PYS_PRO_GLOBAL\GuzzleHttp\Exception\GuzzleException
{
}
