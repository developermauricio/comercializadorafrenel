<?php

namespace PYS_PRO_GLOBAL;

// Don't redefine the functions if included multiple times.
if (!\function_exists('PYS_PRO_GLOBAL\\GuzzleHttp\\describe_type')) {
    require __DIR__ . '/functions.php';
}
