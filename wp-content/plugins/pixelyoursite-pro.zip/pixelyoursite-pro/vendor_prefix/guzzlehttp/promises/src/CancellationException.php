<?php

namespace PYS_PRO_GLOBAL\GuzzleHttp\Promise;

/**
 * Exception that is set as the reason for a promise that has been cancelled.
 */
class CancellationException extends \PYS_PRO_GLOBAL\GuzzleHttp\Promise\RejectionException
{
}
