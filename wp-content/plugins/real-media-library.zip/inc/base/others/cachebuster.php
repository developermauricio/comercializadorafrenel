<?php
/* This file was automatically generated (Wed Dec 01 2021 07:00:40 GMT+0000 (Coordinated Universal Time)). */
return [
    'src/public/dist/rml_gutenberg.lite.js' => '3d37a223a96263169ae2b80a657401a6',
    'src/public/dist/rml_gutenberg.pro.js' => '092861083b3d0f93be211d69a05f4ecd',
    'src/public/dist/rml_shortcode.lite.js' => 'ac9b5017d28809a9b30c828ee021b698',
    'src/public/dist/rml_shortcode.pro.js' => 'e5b64b988d0333c152334a6da4a01250',
    'src/public/dist/rml.lite.js' => '1c21c240efd0a65219a8fbf2c6ff7c51',
    'src/public/dist/rml.pro.js' => '4ecff31d14b2fb7404724b18fe30a914',
    'src/public/dist/rml.css' => '05d076d905bea4538f0f202b133e37dc',
    'src/public/dev/rml_gutenberg.lite.js' => '07fac2e50535773b07abd4e2692e1b62',
    'src/public/dev/rml_gutenberg.pro.js' => '8c2d861688bc4a3afe36da71fbc54eaa',
    'src/public/dev/rml_shortcode.lite.js' => 'ccd9a5da4806d632b926d279f19511ae',
    'src/public/dev/rml_shortcode.pro.js' => '1f11b9b94cf166c5b00ed172763c4d1e',
    'src/public/dev/rml.lite.js' => '545807c0e0596b53015f545723c19efe',
    'src/public/dev/rml.pro.js' => '030aff0e08b6319ef677db8ee0460e96',
    'src/public/dev/rml.css' => 'ddb67605720a19b266f9ba14f2f2be38'
];
